# MFC starter

Upload this folder to input/xenon/MFC/<your-name>/ in ANUHPC/ANUHPC-Leaderboard on main. Commit all files together, or merge a validated PR. Watch Actions: Submit jobs (xenon).

Full instructions: https://github.com/ANUHPC/ANUHPC-Leaderboard/tree/main/input/_TEMPLATES/MFC/practice-task2

Results: https://anuhpc.github.io/ANUHPC-Leaderboard/#/MFC
